package com.cg.app.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.app.model.ReferFriend;
import com.cg.app.service.ReferFriendService;


@RestController
@RequestMapping("/")
public class ReferFriendController {

	@Autowired private ReferFriendService service;
	
	@GetMapping(value="findbymobilenumber")
	public ReferFriend findByMobile(@RequestParam String mobile) {
		System.out.println(mobile);
		return service.findByMobileNumber(mobile);
	}
	
	@GetMapping(value="findbyid")
	public ReferFriend findById(@RequestParam String id) {
		return service.findByid(id);
	}
	
	@PutMapping(value="referral")
	public ResponseEntity<String> referal(@RequestParam String id,@RequestParam String referralcode)
	{
		ReferFriend rf = service.findByid(id);
		
		List<ReferFriend> elist = service.findAll();
		for(ReferFriend e : elist)
			if(e.getReferralcode().equals(referralcode))
			{
				rf.setReferredby(e.getCustName());
			}
		//rf.setReferredby(referralcode);
		rf.setRewards(rf.getRewards()+150D);
		service.update(rf);
		
		
		return new ResponseEntity<String>("Referred successfully",HttpStatus.CREATED);
	}
}
