package com.cg.app.dao;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.app.model.ReferFriend;

@Repository
public interface ReferFriendDao  extends JpaRepository<ReferFriend, String>{
	@Query("select referfriend from ReferFriend referfriend where referfriend.mobilenumber=:mobilenumber")
	 public Optional<ReferFriend> findByMobileNumber(@Param("mobilenumber") String mobilenumber);
	
}
