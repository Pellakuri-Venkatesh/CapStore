package com.cg.app.service;

import java.util.List;

import com.cg.app.model.ReferFriend;

public interface ReferFriendService {
	
	ReferFriend findByid(String id);
	
	void update(ReferFriend rf);

	List<ReferFriend> findAll();
	
	ReferFriend findByMobileNumber(String mobile);

}
