package com.cg.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
//@Table(name="referfriends")
@Table(name="referfriend")
@XmlRootElement
public class ReferFriend {

	@Id @Column(name="userid")
	private String userid;
	
	@Column(name="custname",length=30)
	private String custName;
	
	@Column(name="username",length=30)
	private String username;

	@Column(name="password",length=30)
	private String password;

	@Column(name="referralcode")
	private String referralcode;
	
	
	@Column(name="rewards")
	private Double rewards;
	
	@Column(name="referredby")
	private String referredby;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getReferralcode() {
		return referralcode;
	}

	public void setReferralcode(String referralcode) {
		this.referralcode = referralcode;
	}

	public Double getRewards() {
		return rewards;
	}

	public void setRewards(Double rewards) {
		this.rewards = rewards;
	}

	public String getReferredby() {
		return referredby;
	}

	public void setReferredby(String referredby) {
		this.referredby = referredby;
	}

	@Override
	public String toString() {
		return "ReferFriend [userid=" + userid + ", custName=" + custName + ", username=" + username + ", password="
				+ password + ", referralcode=" + referralcode + ", rewards=" + rewards + ", referredby=" + referredby
				+ "]";
	}
	
	
	
	
	
}
